====
ppug
====


.. image:: https://img.shields.io/pypi/v/ppug.svg
        :target: https://pypi.python.org/pypi/ppug

.. image:: https://img.shields.io/travis/knowsuchagency/ppug.svg
        :target: https://travis-ci.org/knowsuchagency/ppug

.. image:: https://readthedocs.org/projects/ppug/badge/?version=latest
        :target: https://ppug.readthedocs.io/en/latest/?badge=latest
        :alt: Documentation Status

.. image:: https://pyup.io/repos/github/knowsuchagency/ppug/shield.svg
     :target: https://pyup.io/repos/github/knowsuchagency/ppug/
     :alt: Updates


Pug template support in Python


* Free software: MIT license
* Documentation: https://ppug.readthedocs.io.


Features
--------

* TODO

Credits
---------

This package was created with Cookiecutter_ and the `audreyr/cookiecutter-pypackage`_ project template.

.. _Cookiecutter: https://github.com/audreyr/cookiecutter
.. _`audreyr/cookiecutter-pypackage`: https://github.com/audreyr/cookiecutter-pypackage



=======
History
=======

0.1.0 (2017-06-18)
------------------

* First release on PyPI.


