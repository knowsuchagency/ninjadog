====
ppug
====


.. image:: https://img.shields.io/pypi/v/ppug.svg
        :target: https://pypi.python.org/pypi/ppug

.. image:: https://img.shields.io/travis/knowsuchagency/ppug.svg
        :target: https://travis-ci.org/knowsuchagency/ppug

.. image:: https://readthedocs.org/projects/ppug/badge/?version=latest
        :target: https://ppug.readthedocs.io/en/latest/?badge=latest
        :alt: Documentation Status

.. image:: https://pyup.io/repos/github/knowsuchagency/ppug/shield.svg
     :target: https://pyup.io/repos/github/knowsuchagency/ppug/
     :alt: Updates


Pug template support in Python


* Free software: MIT license
* Documentation: https://ppug.readthedocs.io.


Features
--------

* Render `.pug templates <https://pugjs.org/api/getting-started.html>`_ (formerly `jade <https://naltatis.github.io/jade-syntax-docs/>`_)

Usage
-----

You can use the render function to simply render a block of pug-formatted text to html

.. code-block:: python

    from ppug import render

    string = 'h1 hello, world'

    print(render(string)) # -> <h1>hello, world</h1>

You can also use the PugPreprocessor extension to use jinja-template syntax in pug templates

.. code-block:: python

    from jinja2 import Environment
    from ppug.ext.jinja2 import PugPreprocessor

    string = 'h1 hello, {{ name }}'

    env = Environment(extensions=(PugPreprocessor,))

    template = env.from_string(string)

    print(template.render(name='world')) # -> <h1>hello, world</h1>

To use pug templates with Pyramid, simply include them with your configuration
after `pyramid-jinja2`. This will use the PugPreprocessor class to allow you to
use jinja2 template syntax within pug templates.

.. code-block:: python

    config = Configurator()
    config.include('pyramid_jinja2')
    config.include('ppug.ext.pyramid')


Notes
-----

Please note that nodejs must be installed for this package to work.


Credits
---------

This package was created with Cookiecutter_ and the `audreyr/cookiecutter-pypackage`_ project template.

.. _Cookiecutter: https://github.com/audreyr/cookiecutter
.. _`audreyr/cookiecutter-pypackage`: https://github.com/audreyr/cookiecutter-pypackage



=======
History
=======

0.1.0 (2017-06-18)
------------------

* First release on PyPI.


